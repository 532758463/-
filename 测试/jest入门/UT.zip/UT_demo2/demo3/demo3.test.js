import {
    fetchData
} from './demo3'

// Don't do this!
it('本来应该失败的测试用例(断言Hello world===MyWorld) 执行成功了', () => {
    fetchData('world', (result) => {
        expect(result).toBe('MyWorld')
    })
});