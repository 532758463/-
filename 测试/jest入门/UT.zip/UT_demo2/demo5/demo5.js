export const fetchData = (data) => {
    return new Promise((resolve, reject) => {
        if (data === 'peanut butter') {
            resolve(data)
        } else {
            reject('error')
        }
    })
}