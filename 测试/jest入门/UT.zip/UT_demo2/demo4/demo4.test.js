import {
    fetchData
} from './demo4'

it('预期失败的测试用例(断言Hello world===MyWorld) 按照预期结果执行失败', (done) => {
    fetchData('world', (result) => {
        expect(result).toBe('MyWorld')
        done()
    })
});