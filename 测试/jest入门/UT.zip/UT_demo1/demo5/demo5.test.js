describe.each `
    a | b | expected
    ${1} | ${1} | ${2}
    ${1} | ${2} | ${3}
    ${2} | ${1} | ${3}
`('测试$a+$b=$expected', ({
    a,
    b,
    expected
}) => {
    it(`returns ${expected}`, () => {
        expect(a + b).toBe(expected);
    });
});