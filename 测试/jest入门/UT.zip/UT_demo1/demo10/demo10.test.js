const person1 = {
    name: 'Bob',
    age: 12,
};

const person2 = {
    name: 'Bob',
    age: 12,
};

describe('toBe 和 toEqual 比较', () => {
    it('toBe 无法比较两个对象是否相等', () => {
        expect(person1).toBe(person2);
    });

    it('toEqual 可以比较两个对象是否相等', () => {
        expect(person1).toEqual(person2);
    });
});