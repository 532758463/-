describe('验证 .only 运行唯一的一条测试用例', () => {
    it('没有only，不运行的测试用例1', () => {
        expect(1 + 1).toBe(2);
    });

    it('没有only，不运行的测试用例2', () => {
        expect(1 + 1).toBe(2);
    });

    it.only('包含only,唯一运行的测试用例', () => {
        expect(1 + 1).toBe(2);
    });
})