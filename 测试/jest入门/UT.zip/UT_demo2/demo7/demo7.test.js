import {
    fetchData
} from './demo7'

it('异步函数，使用async/await 验证正常结果', async () => {
    expect.assertions(1)
    const data = await fetchData('peanut butter')
    expect(data).toBe('peanut butter')
});
it('异步函数，使用async/await 测试捕获异常', async () => {
    expect.assertions(1)
    try {
        await fetchData()
    } catch (error) {
        expect(error).toMatch('error');
    }
});