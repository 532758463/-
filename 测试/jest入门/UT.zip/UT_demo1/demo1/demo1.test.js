describe('加法测试', () => {
    it('测试1+1等于2', () => {
        expect(1 + 1).toBe(2);
    });
})