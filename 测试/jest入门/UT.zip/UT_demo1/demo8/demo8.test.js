describe('todo 用法示例', () => {
    it('已经完成的测试用例', () => {
        expect(1 + 1).toBe(2);
    });

    it.todo('待编写的测试用例');
})