export const fetchData = (name, callback) => {
    setTimeout(() => {
        callback(`Hello ${name}`)
    }, 1000)
}