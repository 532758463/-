import {
    fetchData
} from './demo6'

it('异步函数，使用resolves', () => {
    expect.assertions(1) // 验证在测试期间是否调用了一定数量的断言
    return expect(fetchData('peanut butter')).resolves.toBe('peanut butter')
});
it('异步函数，使用rejects', () => {
    expect.assertions(1)
    return expect(fetchData()).rejects.toMatch('error');
});