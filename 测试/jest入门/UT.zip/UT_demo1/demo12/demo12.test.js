describe('toContain', () => {
    it('检查项目是否包含在数组中', () => {
        expect([1, 2, 3, 4]).toContain(1);
    });
    it('检查字符串是否包含在另一字符串中', () => {
        expect('can1').not.toBe('can');
    });
});