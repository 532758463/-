const person = {
    name: 'Bob',
    age: 12,
};

describe('toBe 判断对象实例的引用值相等', () => {
    it('person 的name属性值为 Bob', () => {
        expect(person.name).toBe('Bob');
    });

    it('person 的age 属性值为 12', () => {
        expect(person.age).toBe(12);
    });
});