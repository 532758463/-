import {
    fetchData
} from './demo5'

it('peomise get data = peanut butter', () => {
    expect.assertions(1) // 验证在测试期间是否调用了一定数量的断言
    return fetchData('peanut butter').then((data) => {
        expect(data).toBe('peanut butter');
    })
});

it('promise catch error', () => {
    expect.assertions(1)
    return fetchData().catch((e) => {
        expect(e).toMatch('error')
    });
});