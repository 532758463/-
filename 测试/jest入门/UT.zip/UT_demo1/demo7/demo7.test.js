describe('验证 .skip 跳过一条测试用例', () => {
    it('没有skip，运行的测试用例1', () => {
        expect(1 + 1).toBe(2);
    });

    it.skip('有skip，跳过的测试用例2', () => {
        expect(1 + 1).toBe(2);
    });

    it('没有skip，运行的测试用例3', () => {
        expect(1 + 1).toBe(2);
    });
})